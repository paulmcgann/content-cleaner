define(
"dojox/atom/widget/nls/ca/FeedEntryEditor", ({
	doNew: "[nou]",
	edit: "[edita]",
	save: "[desa]",
	cancel: "[cancel·la]"
})
);
