//>>built
define("dojox/atom/widget/nls/hr/PeopleEditor",({add:"Dodaj",addAuthor:"Dodaj autora",addContributor:"Dodaj doprinositelja"}));