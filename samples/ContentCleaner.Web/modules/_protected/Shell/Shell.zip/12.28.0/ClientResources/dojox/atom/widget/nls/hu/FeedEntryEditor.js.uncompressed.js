define(
"dojox/atom/widget/nls/hu/FeedEntryEditor", ({
	doNew: "[új]",
	edit: "[szerkesztés]",
	save: "[mentés]",
	cancel: "[mégse]"
})
);
